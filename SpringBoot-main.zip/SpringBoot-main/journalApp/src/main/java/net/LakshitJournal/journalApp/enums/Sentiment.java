package net.LakshitJournal.journalApp.enums;

public enum Sentiment {

    Happy,
    Sad,
    Angry,
    Anxious;

}
