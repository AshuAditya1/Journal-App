package net.LakshitJournal.journalApp.constants;

public interface Placeholders {

    String API_KEY="<apiKey>";
    String CITY="<city>";

}
